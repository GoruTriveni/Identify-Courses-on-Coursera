

package com.coursera.pages;
import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.openqa.selenium.interactions.Actions;
import com.coursera.utils.ScreenshotUtil;


public class HomePage {
    WebDriver driver;
    
    @FindBy(id = "search-autocomplete-input")
    WebElement searchBox;

    @FindBy(xpath = "//img[@class='rc-CourseraLogo']")
    WebElement courseraLogo;

    @FindBy(xpath = "//a[text()='For Enterprise']")
    WebElement forEnterpriseLink;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }
    

    public void searchCourse(String courseName) throws InterruptedException {
        searchBox.sendKeys(courseName);
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement lang = driver.findElement(By.id("cds-react-aria-:R4onaj6lad6qla:-formLabel"));
        js.executeScript("arguments[0].scrollIntoView()", lang);
        driver.findElement(By.id("cds-react-aria-:R4darconaj6lad6qla:")).click();
        Thread.sleep(3000);
        ScreenshotUtil.captureScreenshot(driver, "Eng_filter");
       

        WebElement level = driver.findElement(By.id("cds-react-aria-:R4p7aj6lad6qla:-formLabel"));
        js.executeScript("arguments[0].scrollIntoView()", level);
        driver.findElement(By.id("cds-react-aria-:R4darcp7aj6lad6qla:-label-text")).click();
        Thread.sleep(3000);
        ScreenshotUtil.captureScreenshot(driver, "Beginner_filter");
        
    }

    public void goToHomePage() {
        courseraLogo.click();
    }

    public void clickForEnterprise() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,-document.body.scrollHeight)");
        forEnterpriseLink.click();
    }
}

