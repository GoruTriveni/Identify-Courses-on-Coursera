
package com.coursera.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class LanguageLearningPage {
    WebDriver driver;

    public LanguageLearningPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void expandAndPrintLanguages() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement langview = driver.findElement(By.id("cds-react-aria-:R4oul6dakqd9ada:-formLabel"));
        js.executeScript("arguments[0].scrollIntoView()", langview);
        driver.findElement(By.xpath("//span[text()='Show 43 more']")).click();
        Thread.sleep(2000);

        List<WebElement> langs = driver.findElements(By.cssSelector("[data-testid^='language:']"));
        System.out.println("Total number of languages: " + langs.size());
        for (WebElement lang : langs) {
            System.out.println(lang.getText());
        }
        System.out.println("-----------------------------------");
        System.out.println();
    }

    public void printLevels() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement levelview = driver.findElement(By.id("cds-react-aria-:R4pul6dakqd9ada:-formLabel"));
        js.executeScript("arguments[0].scrollIntoView()", levelview);
        Thread.sleep(2000);

        List<WebElement> levels = driver.findElements(By.cssSelector("[data-testid^='productDifficultyLevel:']"));
        System.out.println("Total number of levels: " + levels.size());
        for (WebElement level : levels) {
            System.out.println(level.getText());
            System.out.println("-----------------------------------");
            System.out.println();
            
        }
    }
}
