
package com.coursera.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import java.util.List;

public class SearchResultsPage {
    WebDriver driver;

    public SearchResultsPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void printTopCourses(int count) {
        WebElement resultsContainer = driver.findElement(By.id("searchResults"));
        List<WebElement> courseCards = resultsContainer.findElements(By.tagName("li"));

        for (int i = 0; i < count && i < courseCards.size(); i++) {
            WebElement card = courseCards.get(i);
            String courseName = card.findElement(By.xpath(".//h3")).getText();
            String duration = card.findElement(By.xpath(".//div[contains(@class,'cds-CommonCard-metadata')]/p")).getText();
            String rating = card.findElement(By.xpath(".//span[contains(@class,'css-6ecy9b')]")).getText();
            
            System.out.println("----------------------");
            System.out.println("Course: " + courseName);
            System.out.println("Duration: " + duration);
            System.out.println("Rating: " + rating);
            System.out.println("----------------------");
        }
    }
}
