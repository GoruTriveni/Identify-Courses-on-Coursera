
package com.coursera.pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;


public class EnterprisePage {
    WebDriver driver;

    @FindBy(id = "FirstName") WebElement firstName;
    @FindBy(id = "LastName") WebElement lastName;
    @FindBy(id = "Email") WebElement email;
    @FindBy(id = "Phone") WebElement phone;
    @FindBy(id = "rentalField9") WebElement organisation;
    @FindBy(id = "Title") WebElement title;
    @FindBy(id = "Company") WebElement company;
    @FindBy(id = "Employee_Range__c") WebElement companySize;
    @FindBy(id = "What_the_lead_asked_for_on_the_website__c") WebElement needs;
    @FindBy(id = "Country") WebElement country;
    @FindBy(id = "State") WebElement state;
    @FindBy(xpath = "//button[@type='submit']") WebElement submitBtn;
    @FindBy(id = "ValidMsgEmail") WebElement errorMsg;

    public EnterprisePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void fillEnterpriseForm() throws InterruptedException {
        firstName.sendKeys("Rishitha");
        lastName.sendKeys("Koppula");
        email.sendKeys("rishithaKoppula");
        phone.sendKeys("9635119378");
        new Select(organisation).selectByIndex(1);
        title.sendKeys("PAT");
        company.sendKeys("Cognizant");
        new Select(companySize).selectByIndex(5);
        new Select(needs).selectByVisibleText("Courses for myself");
        new Select(country).selectByVisibleText("India");
        new Select(state).selectByVisibleText("Telangana");
        submitBtn.click();
        Thread.sleep(2000);    
    }

	public String getErrorMessageText() {
		return errorMsg.getText();
	}
}