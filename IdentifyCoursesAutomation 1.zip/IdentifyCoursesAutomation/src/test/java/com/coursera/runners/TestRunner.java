package com.coursera.runners;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.*;

@CucumberOptions(
    features = "Features",
    glue = "com.coursera.stepdefinitions",
    plugin = {"pretty", "html:target/cucumber-reports","io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm"},
    monochrome = false
)
public class TestRunner extends AbstractTestNGCucumberTests {

    public static String browserName;
    
    @BeforeClass
    @Parameters({"browser"})
    public void setBrowser(String browser) {
        browserName = browser;
    }

}