package com.coursera.stepdefinitions;

import com.coursera.base.BaseClass;
import com.coursera.pages.*;
import com.coursera.runners.TestRunner;
import com.coursera.utils.ScreenshotUtil;
import com.coursera.pages.EnterprisePage;
import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.en.*;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import com.coursera.utils.AllureReportOpener;
import com.coursera.utils.ExcelWriterUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


public class IdentifyCoursesSteps extends BaseClass {


    private static final Logger logger = LogManager.getLogger(IdentifyCoursesSteps.class);
    
    HomePage home;
    SearchResultsPage searchResults;
    LanguageLearningPage langPage;
    EnterprisePage enterprisePage;
    
    @AfterAll
    public static void tearDown1() {
    	AllureReportOpener.openAllureReport();
    }
    
    @Given("I open Coursera")
    public void i_open_coursera() {
    	initializeDriver(TestRunner.browserName);
        driver.get("https://www.coursera.org");
        logger.info("Opening Coursera");

        // Initialize PageFactory-based page objects
        home = new HomePage(driver);
        searchResults = new SearchResultsPage(driver);
        langPage = new LanguageLearningPage(driver);
        enterprisePage = new EnterprisePage(driver);
    }

    @When("I search for {string}")
    public void i_search_for(String courseName) throws InterruptedException {
    	logger.info("Searching for courseName");
    	try {
    		home.searchCourse(courseName);
    		ExcelWriterUtil.logResult("Search for "+courseName,"Passed");
    	}catch(Exception e){
    		ExcelWriterUtil.logResult("Search for "+courseName,"Failed");
    	}
    }

    @Then("I should see top {int} courses")
    public void i_should_see_top_courses(Integer count) {
    	logger.info("Displaying top 2 courses");

        try {
            searchResults.printTopCourses(count);
            ExcelWriterUtil.logResult("Displayed top " + count + " courses", "Passed");
        } catch (Exception e) {
            ExcelWriterUtil.logResult("Displayed top " + count + " courses", "Failed");
        }

    }

    @And("I navigate to Language Learning section")
    public void i_navigate_to_language_learning_section() throws InterruptedException {
    	logger.info("Navigating to Language Learning");
    	try {
        home.goToHomePage();
        WebElement langLearn=driver.findElement(By.xpath("//h2[text()='Explore Coursera']"));
        JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView()", langLearn);
        Thread.sleep(5000);
        driver.findElement(By.xpath("//div[text()='Language Learning']")).click();
        ExcelWriterUtil.logResult("Navigate to Language Learning section ", "Passed");
    	}
    	catch(Exception e) {
    		ExcelWriterUtil.logResult("Navigate to Language Learning section ", "Failed");
    	}

        // Switch to new tab if opened
        for (String handle : driver.getWindowHandles()) {
            driver.switchTo().window(handle);
        }
    }

    @Then("I should see available languages and levels")
    public void i_should_see_available_languages_and_levels() throws InterruptedException {
    	logger.info("Displaying Available Languages and Levels");
    	try {
        langPage.expandAndPrintLanguages();
        langPage.printLevels();
        ExcelWriterUtil.logResult("All the available languages and levels displayed ", "Passed");
    }catch(Exception e) {
    	ExcelWriterUtil.logResult("All the available languages and levels displayed ", "Failed");
    }}

    @And("I open the Enterprise page")
    public void i_open_the_enterprise_page() {
    	logger.info("Opening the Enterprise Page");
    	try {
        home.clickForEnterprise();
        ExcelWriterUtil.logResult("Opened the Enterprised page", "Passed");
    	}
    	catch(Exception e) {
    	ExcelWriterUtil.logResult("Opened the Enterprised page", "Failed");	
    	}
    }

    @When("I fill the enterprise form")
    public void i_fill_the_enterprise_form() throws InterruptedException {
    	logger.info("Filling the enterprise form");
    	try {
        enterprisePage.fillEnterpriseForm();
        ExcelWriterUtil.logResult("Filled the Enterprise form", "Passed");
        }
    	catch(Exception e) {
    		ExcelWriterUtil.logResult("Filled the Enterprise form", "Failed");	
    	}
    }

    @Then("I should see an error message for invalid email")
    public void i_should_see_an_error_message_for_invalid_email() {
    	logger.info("error messgae capturing");
    	try {
    	System.out.println("Enterprise Form Error: " + enterprisePage.getErrorMessageText());
        ScreenshotUtil.captureScreenshot(driver, "ErrorCapture");
        ExcelWriterUtil.logResult("error message displayed and captured", "Passed");
    	}
    	catch(Exception e){
    		ExcelWriterUtil.logResult("error message displayed and captured", "Failed");
    	}
    
    }
  
    @After
    public void tearDown() {
    ExcelWriterUtil.saveExcel("output/TestResults.xlsx");
    quitDriver();
    }

}

























