package com.coursera.listeners;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;


public class Listeners implements ITestListener {
	public ExtentSparkReporter sr; //UI of the report
	public ExtentReports e;	//populate common info on the reports
	public ExtentTest test; //creating the test case entries in the report and update status of the test methods
	
	public void onStart(ITestContext context) {
	sr=new ExtentSparkReporter(System.getProperty("user.dir")+".//ExtentFolder//myReport.html");
	sr.config().setDocumentTitle("Coursera Automation report"); //title of the report
	sr.config().setReportName("Functional Testing");	//report name
	sr.config().setTheme(Theme.DARK);
	
	e=new ExtentReports();
	e.attachReporter(sr);
	
	e.setSystemInfo("Computer info","localhost");
	e.setSystemInfo("Environment","QA");
	e.setSystemInfo("TesterName", "Rishitha");
	e.setSystemInfo("OS", "Windows11");
	e.setSystemInfo("browserName","chrome,edge");
}
	
	public void onTestSuccess(ITestResult result) {
		test=e.createTest(result.getName());
		test.log(Status.PASS, "Test case PASSED is: "+result.getName());
	}
	
	public void onTestFailure(ITestResult result) {
		test=e.createTest(result.getName());
		test.log(Status.FAIL, "Test case FAILED is: "+result.getName());
		test.log(Status.FAIL, "Test case FAILED cause is: "+result.getThrowable());
	}
	
	public void onTestSkipped(ITestResult result) {
		test=e.createTest(result.getName());
		test.log(Status.SKIP, "Test case SKIPPED is: "+result.getName());
	}
	
	public void onFinish(ITestContext context) {
		e.flush();
	}
	
	
}

